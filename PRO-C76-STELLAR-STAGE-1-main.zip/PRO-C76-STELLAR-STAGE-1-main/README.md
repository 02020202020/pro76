# PRO-C76-STELLAR-STAGE-1
In The Project, Set Up A New Project Folder. Create Different Screens For The App And Add Them To The Stack Navigator.
